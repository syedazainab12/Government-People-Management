const foodSafety = artifacts.require("FoodSafety");

module.exports = function (deployer) {
    deployer.deploy(foodSafety);
}
