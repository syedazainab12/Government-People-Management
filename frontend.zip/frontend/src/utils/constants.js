import abi from './FoodSafety.json'

export const contractABI = abi.abi;
export const contractAddress = "0xaAD3B7D9F58823c4C12868102B9C3FEF6675eE67";