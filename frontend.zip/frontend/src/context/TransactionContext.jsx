import React, { useEffect, useState } from "react";
import { ethers } from "ethers";
import { contractABI, contractAddress } from "../utils/constants";
export const TransactionContext = React.createContext();
const { ethereum } = window;

const getEthereumContract = () => {
    const provider = new ethers.providers.Web3Provider(ethereum);
    const signer = provider.getSigner();
    return new ethers.Contract(contractAddress, contractABI, signer);
}

export const TransactionProvider = ({ children }) => {
    const [currentAccount, setCurrentAccount] = useState("");
    const [ids, setIds] = useState([]);
    const [employeeDetails, setEmployeeDetails] = useState({});
    const [employeeRole, setEmployeeRole] = useState({});
    const [employeeSalary, setEmployeeSalary] = useState({});
    const [employmentBenefit, setEmploymentBenefit] = useState({});

    const [employeeDetailsFormData, setEmployeeDetailsFormData] = useState({
        employeeName: "",
        employeeAge: "",
        employeeCNICnumber: "",
    });
    const [employeeRoleFormData, setEmployeeRoleFormData] = useState({
        employeeRole: [],
    });
    const [employeeSalaryDetailsFormData, setEmployeeSalaryDetailsFormData] = useState({
        employeeSalary: "",
    });
    const [employmentBenefitsFormData, setEmploymentBenefitsFormData] = useState({
        employmentBenefit: [],
    });

    const handleEmployeesDetailsFormData = (e) => {
        setEmployeeDetailsFormData({
            ...employeeDetailsFormData,
            [e.target.name]: e.target.value,
        });

    };
    const handleEmployeeRoleFormData = (e, index) => {
        const values = [...employeeRoleFormData[e.target.name]];
        values[index] = e.target.value;
        setEmployeeRoleFormData({
            ...employeeRoleFormData,
            [e.target.name]: values,
        });
    };
    const handleEmployeeSalaryDetailsFormData = (e) => {
        setEmployeeSalaryDetailsFormData({
            ...employeeSalaryDetailsFormData,
            [e.target.name]: e.target.value,
        })
    }
    const handleEmploymentBenefitsFormData = (e, index) => {
        const values = [...employmentBenefitsFormData[e.target.name]];
        values[index] = e.target.value;
        setEmploymentBenefitsFormData({
            ...employmentBenefitsFormData,
            [e.target.name]: values,
        });
    }

    const checkIfWalletIsConnect = async () => {
        try {
            if (!ethereum) return alert("Please install MetaMask.");

            const accounts = await ethereum.request({ method: "eth_accounts" });
            if (accounts.length) {
                setCurrentAccount(accounts[0]);

            } else {
                console.log("No accounts found");
            }
        } catch (error) {
            console.log(error);
        }
    };
    const connectWallet = async () => {
        try {
            if (!ethereum) return alert("Please install MetaMask.");

            const accounts = await ethereum.request({
                method: "eth_requestAccounts",
            });

            setCurrentAccount(accounts[0]);
            window.location.reload();
        } catch (error) {
            console.log(error);

            throw new Error("No ethereum object");
        }
    };
    const addEmployeeDetails = async () => {
        try {
            const contract = getEthereumContract();
            const transaction = await contract.addEmployeeDetails(
                employeeDetailsFormData.employeeName,
                employeeDetailsFormData.employeeAge,
                employeeDetailsFormData.employeeCNICnumber
            );
            await transaction.wait();
            console.log(`${employeeDetailsFormData.employeeName} added`);
            setEmployeeDetailsFormData({
                employeeName: "",
                employeeAge: "",
                employeeCNICnumber: "",
            });

        } catch (error) {
            console.log(error);
        }
    };
    const addEmployeeRole = async () => {
        try {
            const contract = getEthereumContract();
            const transaction = await contract.addEmployeeRole(
                employeeRoleFormData.employeeRole,
            );
            await transaction.wait();
            console.log(`${employeeRoleFormData.employeeRole} added`);
            setEmployeeRoleFormData({
                employeeRole: [],
            });
        } catch (error) {
            console.log(error);
        }
    };
    const addEmployeeSalary = async () => {
        try {
            const contract = getEthereumContract();
            const transaction = await contract.addEmployeeSalary(
                employeeSalaryDetailsFormData.employeeSalary
            );
            await transaction.wait();
            console.log(`${employeeSalaryDetailsFormData.employeeSalary} added`);
            setEmployeeSalaryDetailsFormData({
                employeeSalary: "",
            });

        } catch (error) {
            console.log(error);
        }
    };
    const addEmploymentBenefit = async () => {
        try {
            const contract = getEthereumContract();
            const transaction = await contract.addEmploymentBenefit(
                employmentBenefitsFormData.employmentBenefit,
            );
            await transaction.wait();
            console.log(`${employmentBenefitsFormData.employmentBenefit} added`);
            setEmploymentBenefitsFormData({
                employmentBenefit: [],
            });
        } catch (error) {
            console.log(error);
        }
    };

    const sendTransactions = async () => {
        addEmployeeDetails();
        addEmployeeRole();
        addEmployeeSalary();
        addEmploymentBenefit();
    }

    const getIds = async () => {
        const transactionContract = getEthereumContract()
        const allIds = await transactionContract.getIDs();
        //convert to number
        let temp = Number(allIds["_hex"])
        console.log("temp = " , temp);
        // array from 0 to temp
        let arr = Array.from({ length: temp }, (_, i) => i);
        console.log("IDS: " , arr);
        setIds(arr);
    }


    const getById = async (id) => {
        const transactionContract = getEthereumContract()
        const data = await transactionContract.getByID(id);
        setEmployeeDetails(data[0]);
        setEmployeeRole(data[1]);
        setEmployeeSalary(data[2]);
        setEmploymentBenefit(data[3]);

    }

    useEffect(() => {
        checkIfWalletIsConnect();
    }, []);
    return (
        <TransactionContext.Provider
            value={{
                currentAccount,
                connectWallet,
                employeeDetailsFormData,
                handleEmployeesDetailsFormData,
                employeeRoleFormData,
                handleEmployeeRoleFormData,
                sendTransactions,
                ids,
                getIds,
                getById,
                employeeDetails,
                employeeRole,
                employeeSalary,
                employeeSalaryDetailsFormData,
                handleEmployeeSalaryDetailsFormData,
                employmentBenefit,
                employmentBenefitsFormData,
                handleEmploymentBenefitsFormData,
            }}
        >
            {children}
        </TransactionContext.Provider>
    );
}
