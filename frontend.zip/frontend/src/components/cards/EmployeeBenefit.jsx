import React, { useState, useEffect } from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
const EmployeeBenefit = ({ benefit }) => {
   
    const [data, setData] = useState([])
    let allBenefits = []
    const generateCards = () => {
        for (let i = 0; i < benefit.employmentBenefit.length; i++) {
            allBenefits.push(
                <div className="view-item">
                    <Card sx={{ minWidth: 275 }}>
                        <CardContent>
                            <Typography sx={{ fontSize: 14 }} color="text.primary" gutterBottom>
                                Employee Benefits: {benefit.employmentBenefit[i]}
                            </Typography>
                        </CardContent>
                    </Card>
                </div>
            )
        }
    }
    useEffect(() => {
        generateCards()
        setData(allBenefits)
    }, [data])


    return (
        <div className='view-container'>
            {data}

        </div>

    )
}

export default EmployeeBenefit