import React from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
const Salary = ({ employeesalary }) => {
    return (
        <div className='view-container'>
            <div className="view-item">
                <Card sx={{ maxWidth: 275, }}>
                    <CardContent>
                        <Typography sx={{ fontSize: 14 }} color="text.primary" gutterBottom>
                            Salary: {employeesalary.employeeSalary}
                        </Typography>
                    </CardContent>

                </Card>
            </div>
        </div>
    )
}

export default Salary