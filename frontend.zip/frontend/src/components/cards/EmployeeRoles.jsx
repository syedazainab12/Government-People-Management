import React, { useState, useEffect } from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
const EmployeeRoles = ({ role }) => {
   
    const [data, setData] = useState([])
    let allRoles = []
    const generateCards = () => {
        for (let i = 0; i < role.employeeRole.length; i++) {
            allRoles.push(
                <div className="view-item">
                    <Card sx={{ minWidth: 275 }}>
                        <CardContent>
                            <Typography sx={{ fontSize: 14 }} color="text.primary" gutterBottom>
                                Employee Roles: {role.employeeRole[i]}
                            </Typography>
                        </CardContent>
                    </Card>
                </div>
            )
        }
    }
    useEffect(() => {
        generateCards()
        setData(allRoles)
    }, [data])


    return (
        <div className='view-container'>
            {data}

        </div>

    )
}

export default EmployeeRoles