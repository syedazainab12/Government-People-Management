import React from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
const Distribution = ({ distributor }) => {
    return (
        <div className='view-container'>
            <div className="view-item">
                <Card sx={{ maxWidth: 275, }}>
                    <CardContent>
                        <Typography sx={{ fontSize: 14 }} color="text.primary" gutterBottom>
                            Distributor: {distributor.distributorName}
                        </Typography>
                        <Typography variant="body2">
                            Distributor address: {distributor.distributorAddress}
                        </Typography>
                        <Typography variant="body2">
                            Distributor email: {distributor.distributorEmail}
                        </Typography>
                        <Typography variant="body2">
                            Distributor phone: {distributor.distributorPhone}
                        </Typography>

                    </CardContent>

                </Card>
            </div>
        </div>
    )
}

export default Distribution