import React from 'react'
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
const EmployeeDetails = ({ details }) => {
    return (
        <div className='view-container'>
        <div className="view-item">
            <Card sx={{ maxWidth: 275, }}>
                <CardContent>
                    <Typography sx={{ fontSize: 14 }} color="text.primary" gutterBottom>
                        Employee: {details.employeeName}
                    </Typography>
                    <Typography variant="body2">
                        Employee age: {details.employeeAge}
                    </Typography>
                    <Typography variant="body2">
                        Employee CNIC: {details.employeeCNICnumber}
                    </Typography>
                </CardContent>

            </Card>
        </div>
    </div>
    )
}

export default EmployeeDetails