import React, { useState, SyntheticEvent, useContext, useEffect } from 'react'
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import EmployeeDetails from './cards/EmployeeDetails'
import Salary from './cards/Salary';
import EmployeeRoles from './cards/EmployeeRoles';
import { TransactionContext } from '../context/TransactionContext';
import { useLocation } from 'react-router-dom';
import EmployeeBenefit from './cards/EmployeeBenefit';

const View = () => {
    const locationS = useLocation();
    const selectedId = locationS.state.id;
    const [value, setValue] = useState('Food details');
    const { getIds,
        ids,
        getById,
        employeeDetails,
        employeeRole,
        employeeSalary,
        employmentBenefit
        
    } = useContext(TransactionContext);

    const handleChange = (event: SyntheticEvent, newValue: string) => {
        setValue(newValue);
    };
    useEffect(() => {
        getById(selectedId);
    }, []);

    return (
        <div className='container' >
            <div className='dashboard-container'>
                <Tabs
                    value={value}
                    onChange={handleChange}
                    textColor="primary"
                    indicatorColor="primary"
                    aria-label="secondary tabs example"
                >
                    <Tab value="Employee details" label="Employee details" />
                    <Tab value="Employee Roles" label="Employee Roles" />
                    <Tab value="Employee salary" label="Employee salary " />
                    <Tab value="Employee benefits" label="Employee benefits" />

                </Tabs>
                <div className='view-container'>
                    {value === 'Employee details' &&

                        <EmployeeDetails details={employeeDetails} />

                    }

                    {
                        value === 'Employee Roles' &&
                        <EmployeeRoles role={employeeRole} />
                    }

                    {

                        value === 'Employee salary' &&
                        <Salary employeesalary={employeeSalary}/>
                    }

                    {
                        value === 'Employee benefits' &&
                        // console.log("WTF IS GOING ON: " , employmentBenefit)
                        <EmployeeBenefit benefit={employmentBenefit}/>
                    }



                </div>
            </div>
        </div >
    )
}

export default View