import React, { useState, SyntheticEvent, useContext, useEffect } from 'react'
import Box from '@mui/material/Box';
import { TransactionContext } from '../context/TransactionContext';
import { useNavigate } from "react-router-dom";

const Txns = () => {
    const { getIds, ids } = useContext(TransactionContext);
    useEffect(() => {
        getIds();
    }, []);
    const navigate = useNavigate();
    const printIds = () => {
        return (
            <div >
                {ids.map((id) => (
                    <div style={{ color: 'black', cursor: "pointer" }} onClick={
                        () => {
                            navigate('/view', { state: { id: id } })
                        }
                    }
                    >
                        <h3>{id}</h3>
                    </div>

                ))}
            </div>
        );
    };


    return (
        <div className='container'>
            <div className='txn-container'>
                <h1 >Transactions</h1>
                {printIds()}
            </div>
        </div>
    )
}

export default Txns