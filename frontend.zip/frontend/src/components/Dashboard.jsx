import React, { useState, SyntheticEvent, useContext } from 'react'
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import { useNavigate } from "react-router-dom";

import { TransactionContext } from '../context/TransactionContext';

const Dashboard = () => {
    const [value, setValue] = useState('Employee details');
    const [countArrayRoles, setcountArrayRoles] = useState([0]);
    const [countArrayBenefits, setcountArrayBenefits] = useState([0]);
    const navigate = useNavigate();
    const {
        employeeDetailsFormData,
        handleEmployeesDetailsFormData,

        employeeRoleFormData,
        handleEmployeeRoleFormData,

        employeeSalaryDetailsFormData,
        handleEmployeeSalaryDetailsFormData,

        employmentBenefitsFormData,
        handleEmploymentBenefitsFormData,

        sendTransactions

    }
        = useContext(TransactionContext);
    const handleChange = (event: SyntheticEvent, newValue: string) => {
        setValue(newValue);
    };
    const handleIncrementRoles = () => {
        if (countArrayRoles.length < 5) {
            setcountArrayRoles([...countArrayRoles, countArrayRoles.length])
        }
        else {
            alert("Maximum 5 items allowed")
        }

    }
    const handleIncrementBenefits = () => {
        if (countArrayBenefits.length < 5) {
            setcountArrayBenefits([...countArrayBenefits, countArrayBenefits.length])
        }
        else {
            alert("Maximum 5 items allowed")
        }

    }
    const handleSubmit = () => {
        const { employeeName, employeeAge, employeeCNICnumber } = employeeDetailsFormData;
        const { employeeRole } = employeeRoleFormData;
        const { employeeSalary } = employeeSalaryDetailsFormData;
        const { employmentBenefit } = employmentBenefitsFormData;

        if (employeeName != "" && employeeAge != "" && employeeCNICnumber != "" && employeeRole[0] != undefined && employeeSalary != "" && employmentBenefit[0] != undefined) {
            console.log("SENDING TXNS!!")
            sendTransactions()
        }
        else {
            alert("Please fill all the fields")
        }
    }
    return (
        <div className='container'>
            <div className='dashboard-container'>
                <Tabs
                    value={value}
                    onChange={handleChange}
                    textColor="primary"
                    indicatorColor="primary"
                    aria-label="secondary tabs example"
                >
                    <Tab value="Employee details" label="Employee details" />
                    <Tab value="Employee role and duties" label="Employee role and duties" />
                    <Tab value="Employee salary" label="Employee salary" />
                    <Tab value="Employee Benefits" label="Employee Benefits" />
                </Tabs>
                <div className={countArrayRoles.length > 3  && (countArrayBenefits.length > 3) && (value == "Employee role and duties" || value == "Employee Benefits") ? 'input-container-bigger' : 'input-container'}>

                    <Box
                        component="form"
                        sx={{
                            '& .MuiTextField-root': {
                                m: 1, width: '25ch', marginTop: '15px',
                            },
                        }}
                        noValidate
                        autoComplete="off"
                    >
                        {
                            value === 'Employee details' ? (
                                <div>
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Employee name"
                                        name="employeeName"
                                        value={employeeDetailsFormData.employeeName}
                                        // onChange={handleEmployeesDetailsFormData}
                                        onChange={(e) => handleEmployeesDetailsFormData(e)}

                                    />
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Employee age"
                                        name="employeeAge"
                                        value={employeeDetailsFormData.employeeAge}
                                        // onChange={handleEmployeesDetailsFormData}
                                        onChange={(e) => handleEmployeesDetailsFormData(e)}

                                    />
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Employee CNIC number"
                                        name="employeeCNICnumber"
                                        value={employeeDetailsFormData.employeeCNICnumber}
                                        onChange={(e) => handleEmployeesDetailsFormData(e)}
                                    />

                                    <div className='submit-button'>
                                        <Button variant="contained" onClick={() => { setValue("Employee role and duties") }}>Next</Button>
                                    </div>
                                </div>

                            ) : value === 'Employee role and duties' ? (
                                <div>
                                    {console.log(employeeRoleFormData.employeeRole[0])}
                                    {
                                        countArrayRoles.map((item, index) => {
                                            return (
                                                <div key={index}>
                                                    <div className='raw-suppy-row'>
                                                        <TextField
                                                            required
                                                            id="outlined-required"
                                                            label="Role"
                                                            name="employeeRole"
                                                            value={employeeRoleFormData.employeeRole[index]}
                                                            onChange={(e) => handleEmployeeRoleFormData(e, index)}
                                                        />
                                                    </div>
                                                </div>
                                            )
                                        }
                                        )
                                    }
                                    <div className='button-row'>
                                        <div className="ml-2 mt-2">
                                            <Button variant="contained" onClick={handleIncrementRoles}>Add more</Button>
                                        </div>
                                    </div>
                                </div>
                            ) : value === "Employee salary" ? (
                                <div>
                                    <TextField
                                        required
                                        id="outlined-required"
                                        label="Employee salary"
                                        name="employeeSalary"
                                        value={employeeSalaryDetailsFormData.employeeSalary}
                                        // onChange={handleEmployeesDetailsFormData}
                                        onChange={(e) => handleEmployeeSalaryDetailsFormData(e)}

                                    />
                                </div>
                            ) : value === 'Employee Benefits' ? (
                                <div>
                                    {console.log(employmentBenefitsFormData.employmentBenefit[0])}
                                    {
                                        countArrayBenefits.map((item, index) => {
                                            return (
                                                <div key={index}>
                                                    <div className='raw-suppy-row'>
                                                        <TextField
                                                            required
                                                            id="outlined-required"
                                                            label="Benefit"
                                                            name="employmentBenefit"
                                                            value={employmentBenefitsFormData.employmentBenefit[index]}
                                                            onChange={(e) => handleEmploymentBenefitsFormData(e, index)}
                                                        />
                                                    </div>
                                                </div>
                                            )
                                        }
                                        )
                                    }
                                    <div className='button-row'>
                                        <div className="ml-2 mt-2">
                                            <Button variant="contained" onClick={handleIncrementBenefits}>Add more</Button>
                                        </div>
                                    </div>
                                    <div className='submit-button'>
                                        <Button variant="contained" onClick={handleSubmit} >Submit</Button>
                                     </div>
                                </div>
                            )
                            
                            : null
                        }

                    </Box>

                </div>

                <div className='view-button'>
                    <Button variant="contained"
                        onClick={() => { navigate('/txns') }}
                    >View Transactions</Button>
                </div>
                <div className='view-button'>
                    <Button variant="contained"
                        onClick={() => { navigate('/search') }}
                    >Search</Button>
                </div>
            </div >

        </div >
    )
}

export default Dashboard