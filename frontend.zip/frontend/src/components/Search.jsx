import React, { useState, SyntheticEvent, useContext, useEffect } from 'react'
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { TransactionContext } from '../context/TransactionContext';
import { useNavigate } from "react-router-dom";

const Search = () => {
    const navigate = useNavigate();
    const { getIds, ids } = useContext(TransactionContext);
    const [value, setValue] = useState("");
    useEffect(() => {
        getIds();
    }, []);

    const handleSubmit = async () => {
        if (value >= ids.length) {
            alert('Invalid ID');
        }
        else {
            navigate('/view', { state: { id: value } })
        }
    }
    return (
        <div className='container'>
            <div className='dashboard-container'>
                {/* make a search box */}
                <TextField
                    id='outlined-basic'
                    label='Enter the ID'
                    variant='outlined'
                    size='small'
                    sx={{ width: '50%' }}
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                />
                <Button variant='contained' onClick={handleSubmit} sx={{ width: '50%', marginTop: '-30rem' }}>Search</Button>


            </div>
        </div>
    )
}

export default Search